import sys
import os
import math
import datetime
import random
import pygame

def distance(p, q):
	return math.sqrt((p[0]-q[0])**2 + (p[1]-q[1])**2)

def loadSound(file):
	"""Загрузка звука по имени"""
	return pygame.mixer.Sound(os.path.join('sounds', file))

def loadImage(file):
	"""Загрузка изображений по имени"""
	return pygame.image.load(os.path.join('images', file)).convert_alpha()

def drawСentered(surface1, surface2, pos):
	"""Отрисовка сюрфейса на втором сюрфейсе по центру"""
	rect = surface1.get_rect()
	rect = rect.move(pos[0]-rect.width//2, pos[1]-rect.height//2)
	surface2.blit(surface1, rect)

def rotateCenter(image, rect, angle):
		"""Поворот картинки вокруг центра"""
		rotate_img = pygame.transform.rotate(image, angle)
		rotate_rect = rotate_img.get_rect(center=rect.center)
		return rotate_img,rotate_rect




class GameObject:
	"""Базовый объект с кордами и картинкой"""
	def __init__(self, position, image, speed=0):
		self.image = image
		self.position = list(position[:])
		self.speed = speed

	def size(self):
		return max(self.image.get_height(), self.image.get_width())

	def radius(self):
		return self.image.get_width()/2

	def drawOn(self, screen):
		drawСentered(self.image, screen, self.position)


class Spaceship(GameObject):
	def __init__(self, position):
		"""Объект космического корабля"""
		super(Spaceship, self).__init__(position,\
			loadImage('spaceship-off.png'))
		
		self.direction = [0, -1]
		self.is_throttle_on = False
		self.angle = 0
		self.image_on = loadImage('spaceship-on.png')

		self.activeMissiles = []

	def drawOn(self, screen):
		"""Отрисовка корабля на экране"""

		if self.is_throttle_on:
			new_image, rect = rotateCenter(self.image_on, \
				self.image_on.get_rect(), self.angle)
		else:
			new_image, rect = rotateCenter(self.image, \
				self.image.get_rect(), self.angle)
		
		drawСentered(new_image, screen, self.position)


	def move(self):
		"""Do one frame's worth of updating for the object"""
		
		# Расчет направления по углу
		self.direction[1] = -math.cos(math.radians(self.angle))
		self.direction[0] = math.sin(-math.radians(self.angle))
		

		# Расчет позиции из направления и скорости
		self.position[1] += self.direction[1]*self.speed
		self.position[0] += self.direction[0]*self.speed


	def fire(self):
		"""Создание новой ракеты и выстрел"""

		# Необходимо изменить позицию выстрела ракеты
		# к переду корабля
		
		adjust = [0, 0]
		adjust[1] = -math.cos(math.radians(self.angle))*self.image.get_height()
		adjust[0] = math.sin(-math.radians(self.angle))*self.image.get_width()
		
		# Создаем новую ракету
		# используем координаты чтобы ракета встала
		# у переда
		new_missile = Missile(
			(self.position[0]+adjust[0],
			self.position[1]+adjust[1]/2),
			self.angle
		)
		self.activeMissiles.append(new_missile)



class Missile(GameObject):
	"""Ну и ракеты)"""
	def __init__(self, position, angle, speed=15):
		super(Missile, self).__init__(position,\
			loadImage('missile.png'))

		self.direction = [0, 0]
		self.angle = angle
		self.speed = speed


	def move(self):
		# Расчет направления по углу
		self.direction[1] = -math.cos(math.radians(self.angle))
		self.direction[0] = math.sin(-math.radians(self.angle))
		

		# Расчет позиции из направления и скорости
		self.position[1] += self.direction[1]*self.speed
		self.position[0] += self.direction[0]*self.speed


class Rock(GameObject):
	"""Камушек"""
	def __init__(self, position, size, speed=4):

		# Валидация размера
		if size in {"big", "normal", "small"}:

			# загружает файл нужного камня
			str_filename = "rock-" + str(size) + ".png"
			super(Rock, self).__init__(position,\
				loadImage(str_filename))
			self.size = size
		
		else:
			return None

		self.speed = speed
		self.position = list(position)

		
		#Рандомные передвижения
		if bool(random.getrandbits(1)):
			rand_y = random.random() * -1
		else:
			rand_y = random.random()

		if bool(random.getrandbits(1)):
			rand_x = random.random()* -1
		else:
			rand_x = random.random()

		self.direction = [rand_x, rand_y]


	def move(self):
		self.position[1] += self.direction[1]*self.speed
		self.position[0] += self.direction[0]*self.speed



class MyGame:

	# Статусы игры
	PLAYING, DYING, gameOver, STARTING, WELCOME = range(5)

	# События
	REFRESH, START, RESTART = range(pygame.USEREVENT, pygame.USEREVENT+3)

	def __init__(self):
		"""Инициализация игры"""
		pygame.mixer.init()
		pygame.mixer.pre_init(44100, -16, 2, 2048)
		pygame.init()

		self.width = 800
		self.height = 600
		self.screen = pygame.display.set_mode((self.width, self.height))

		# Черный фон
		self.bg_color = 0, 0, 0

		# Загрузка саундтрека
		self.soundtrack = loadSound('soundtrack.wav')
		self.soundtrack.set_volume(.3)

		# Звуки смерти, конца игры, и ракет
		self.die_sound = loadSound('die.wav')
		self.gameover_sound = loadSound('game_over.wav')
		self.missile_sound = loadSound('fire.wav')

		# Получаем системный шрифт, различных размеров (100, 50, 25)
		self.big_font = pygame.font.SysFont(None, 100)
		self.medium_font = pygame.font.SysFont(None, 50)
		self.small_font = pygame.font.SysFont(None, 25)
		# Текст окончания игры самым большим шрифтом
		self.gameoverText = self.big_font.render('Вы проиграли',\
			True, (255, 0, 0))

		# Загрузка изображений для отображения жизней
		self.lives_image = loadImage('live.png')

		# Таймер обновления фпс
		self.FPS = 30
		pygame.time.set_timer(self.REFRESH, 1000//self.FPS)

		# Дистанции смерти различных камней
		self.death_distances = {"big":90,"normal":65 ,"small":40}

		# Отобразить экран приветсвия
		self.doWelcome()

		#Ограничитель слишком быстрой стрельбы ракет
		self.fire_time = datetime.datetime.now()


	def doWelcome(self):
		"""Создает экран приветсвия"""

		# Переход к стадии приветсвия
		self.state = MyGame.WELCOME

		# making the welcome title and description
		self.welcome_label = self.big_font.render("Рэйнджер",\
												True, (255, 215, 0))
		self.welcome_desc =  self.medium_font.render(\
			"[Enter/Клик мышкой] чтобы начать!", True, (35, 107, 142))


	def doInit(self):
		"""Эта функция вызывается при начале игры либо при запуске"""

		self.rocks = []

		# Минимальное расстояние на котором могут появлятся
		# камни, зависит от сложности
		
		self.min_rock_distance = 350

		# Запуск игры
		self.start()

		self.lives = 3
		self.score = 0
		self.counter = 0

		# Создаем 4 больших камня
		for i in range(4):
			self.makeRock()

	def makeRock(self, size="big", pos=None):
		"""Создание нового камня"""

		margin = 200

		if pos == None:
			# Если локация не задана берем случайную

			rand_y = random.randint(margin, self.height-margin)
			rand_x = random.randint(margin, self.width-margin)
			
			
			# Если слишком близко создаем новый
			while distance((rand_x, rand_y), self.spaceship.position) < \
					self.min_rock_distance:
				
				# Выбираем другую случайную координату
				rand_y = random.randint(0, self.height)
				rand_x = random.randint(0, self.width)

			tmpRock = Rock((rand_x, rand_y), size)

		else:
			# Позиция задана в аргументах
			tmpRock = Rock(pos, size)

		# Добавляем камень к списку всех камней
		self.rocks.append(tmpRock)


	def start(self):
		"""Начинает игру созданием корабля"""
		self.spaceship = Spaceship((self.width//2, self.height//2))
		self.missiles = []

		# Саундтрек на повтор
		self.soundtrack.play(-1, 0, 1000)

		self.state = MyGame.PLAYING


	def run(self):
		"""Бесконечный цикл игры"""
		running = True
		while running:
			event = pygame.event.wait()

			if event.type == pygame.QUIT:
				running = False

			# Отрисовываем новый фрейм
			elif event.type == MyGame.REFRESH:
				
				if self.state != MyGame.WELCOME:

					keys = pygame.key.get_pressed()
				
					if keys[pygame.K_SPACE]:
						newTime = datetime.datetime.now()
						if newTime - self.fire_time > \
								datetime.timedelta(seconds=0.15):
							# Задержка между выстрелами

							self.spaceship.fire()
							self.missile_sound.play()

							# Запись времени выстрела
							self.fire_time = newTime

					if self.state == MyGame.PLAYING:
						# Игра идет

						# Повороты корабля
						if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
							self.spaceship.angle -= 10
							self.spaceship.angle %= 360

						if keys[pygame.K_LEFT] or keys[pygame.K_a]:
							self.spaceship.angle += 10
							self.spaceship.angle %= 360

						# Ускорение
						if keys[pygame.K_UP] or keys[pygame.K_w]:
							self.spaceship.is_throttle_on = True
							
							# Увеличиваем скорость
							if self.spaceship.speed < 20:
								self.spaceship.speed += 1
						else:
							# Корабль должен сам терять скорость
							if self.spaceship.speed > 0:
								self.spaceship.speed -= 1
							self.spaceship.is_throttle_on = False

						# Мы должны отработать физику ракет
						if len(self.spaceship.activeMissiles) > 0:
							self.missilesPhysics()

						# И физику камней
						if len(self.rocks) > 0:
							self.rocksPhysics()

						# Физика корабля
						self.physics()

				# Отрисовываем все
				self.draw()

			# Продолжение после потери жизни
			elif event.type == MyGame.START:
				pygame.time.set_timer(MyGame.START, 0) # Отключение таймера
				if self.lives < 1:
					self.gameOver()
				else:
					self.rocks = []
					# Спавним 4 камня
					for i in range(4):
						self.makeRock()
					# Запускаем снова
					self.start()

			# Переключение из экрана окончания игры
			elif event.type == MyGame.RESTART:
				pygame.time.set_timer(MyGame.RESTART, 0) # Выключение таймера
				self.state = MyGame.STARTING

			# Начало новой игры
			elif event.type == pygame.MOUSEBUTTONDOWN \
					and (self.state == MyGame.STARTING or\
							self.state == MyGame.WELCOME):
				self.doInit()

			elif event.type == pygame.KEYDOWN \
					and event.key == pygame.K_RETURN and \
						(self.state == MyGame.STARTING or \
							self.state == MyGame.WELCOME):
				self.doInit()

			else:
				pass


	def gameOver(self):
		"""Потеря жизни"""
		self.soundtrack.stop()
		# Проигрышь звука окончания игры
		self.state = MyGame.gameOver
		self.gameover_sound.play()
		delay = int((self.gameover_sound.get_length()+1)*1000)
		pygame.time.set_timer(MyGame.RESTART, delay)


	def die(self):
		self.soundtrack.stop()
		
		self.lives -= 1
		self.counter = 0
		self.state = MyGame.DYING
		self.die_sound.play()
		delay = int((self.die_sound.get_length()+1)*1000)
		pygame.time.set_timer(MyGame.START, delay)


	def physics(self):
		"""Физика корабля"""
		
		if self.state == MyGame.PLAYING:
			self.spaceship.move()


	def missilesPhysics(self):
		"""Физика ракет"""
		
		# Есть ли активные ракеты
		if len(self.spaceship.activeMissiles) >  0:
			for missile in self.spaceship.activeMissiles:
				# Двигаем ракеты
				missile.move()

				# Проверяем колизию камней
				for rock in self.rocks:
					if rock.size == "big":
						# Если ракета ударяется о большой камень
						# Разделяем камень на кусочки +20
						if distance(missile.position, rock.position) < 80:
							self.rocks.remove(rock)
							if missile in self.spaceship.activeMissiles:
								self.spaceship.activeMissiles.remove(missile)
							self.makeRock("normal", \
								(rock.position[0]+10, rock.position[1]))
							self.makeRock("normal", \
								(rock.position[0]-10, rock.position[1]))
							self.score += 20

					elif rock.size == "normal":
						# Если ракета ударяется о средний камень
						# Разделяем камень на кусочки +50
						if distance(missile.position, rock.position) < 55:
							self.rocks.remove(rock)
							if missile in self.spaceship.activeMissiles:
								self.spaceship.activeMissiles.remove(missile)
							self.makeRock("small", \
								(rock.position[0]+10, rock.position[1]))
							self.makeRock("small", \
								(rock.position[0]-10, rock.position[1]))
							self.score += 50
					else:
						# Если ракета ударяется о маленький камень +100
						# Спавним камни если недостаточно
						if distance(missile.position, rock.position) < 30:
							self.rocks.remove(rock)
							if missile in self.spaceship.activeMissiles:
								self.spaceship.activeMissiles.remove(missile)
							
							if len(self.rocks) < 10:
								self.makeRock()
							
							self.score += 100


	def rocksPhysics(self):
		"""Физика камней"""

		if len(self.rocks) > 0:

			for rock in self.rocks:
				# Двигаем камни
				rock.move()


				# Если камень ударется о корабль он получает по лицу
				if distance(rock.position, self.spaceship.position) < \
						self.death_distances[rock.size]:
					self.die()

				# Проверка количества камней на экране
				elif distance(rock.position, (self.width/2, self.height/2)) > \
					 math.sqrt((self.width/2)**2 + (self.height/2)**2):

					self.rocks.remove(rock)
					if len(self.rocks) < 10:
						self.makeRock(rock.size)


	def draw(self):
		self.screen.fill(self.bg_color)

		if self.state != MyGame.WELCOME:

			# Отрисовываем корабль
			self.spaceship.drawOn(self.screen)

			# Если есть ракеты, то рисуем их
			if len(self.spaceship.activeMissiles) >  0:
				for missile in self.spaceship.activeMissiles:
					missile.drawOn(self.screen)

			# Рисуем камни
			if len(self.rocks) >  0:
				for rock in self.rocks:
					rock.drawOn(self.screen)

			# Режим игры
			if self.state == MyGame.PLAYING:

				self.counter += 1

				if self.counter == 20*self.FPS:
				# Повышаем сложность со временем

					if len(self.rocks) < 15:
						self.makeRock()

					# Уменьшаем дистанцию между новыми камнями
					if self.min_rock_distance < 200:
						self.min_rock_distance -= 50

					self.counter = 0

			# Текст очков
			scores_text = self.medium_font.render(
				'Счет: '+str(self.score),
				True,
				(0, 155, 0)
			)

			drawСentered(
				scores_text,
				self.screen,
				(
					self.width-scores_text.get_width(),
					scores_text.get_height()+10
				)
			)

			if self.state == MyGame.gameOver or self.state == MyGame.STARTING:
				drawСentered(self.gameoverText, self.screen,\
								(self.width//2, self.height//2))

			# Отрисуем жизни
			for i in range(self.lives):
				drawСentered(
					self.lives_image,
					self.screen,
					(
						self.lives_image.get_width()*i*1.2+40,
						self.lives_image.get_height()//2
					)
				)

		else:
			# Рисуем приветсвенный текст
			drawСentered(
				self.welcome_label,
				self.screen,
				(
					self.width//2,
					self.height//2-self.welcome_label.get_height()
				)
			)

			drawСentered(
				self.welcome_desc,
				self.screen,
				(
					self.width//2,
					self.height//2+self.welcome_desc.get_height()
				)
			)

		# Делаем флип буферов и отрисовываем все
		pygame.display.flip()


MyGame().run()
pygame.quit()
sys.exit()
